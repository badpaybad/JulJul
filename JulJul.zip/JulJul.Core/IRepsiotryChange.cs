﻿using System;

namespace JulJul.Core
{
    public interface IRepsiotrySubcribeChange
    {
        void SubscribeAndMakeChange();


    }
}