﻿using System;
using System.ComponentModel.DataAnnotations;

namespace JulJul.Core
{
    public interface IEntity
    {
        [Key]
        Guid Id { get; set; }

        string EntityName();
        string GetEntityName();

        string GetChannelKey();
    }
}