﻿using System;
using System.ComponentModel.DataAnnotations;

namespace JulJul.Core
{
    public abstract class AbstractEntity : IEntity
    {
        protected AbstractEntity()
        {
        }

        [Key]
        public virtual Guid Id { get; set; } = Guid.NewGuid();

        public string EntityName()
        {
            return this.GetType().Name;
        }

        public string GetEntityName()
        {
            return this.GetType().Name;
        }

        public string GetChannelKey()
        {
            return this.GetType().FullName;
        }
    }
}