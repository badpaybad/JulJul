﻿namespace JulJul.Core.Redis
{
    public class RedisConfig
    {
        public string Host { get; set; }
        public int Port { get; set; }
        public string Pwd { get; set; }
    }
}