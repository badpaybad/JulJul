﻿using JulJul.Core;
using JulJul.Core.Domain;

namespace JulJul.Repository
{
    public interface IUserRepository : IRepository<User>
    {
    }
}