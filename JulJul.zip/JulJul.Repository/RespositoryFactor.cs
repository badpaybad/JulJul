﻿using System;
using System.Collections.Generic;
using JulJul.Core;
using JulJul.Core.Distributed;
using JulJul.Core.Domain;

namespace JulJul.Repository
{
    public static class RepositoryFactor
    {
        static Dictionary<Type, object> _mapEntity = new Dictionary<Type, object>();
        static Dictionary<Type, object> _mapRepo = new Dictionary<Type, object>();

        private static RepositoryServices _repositoryServices = RepositoryServices.Instance;

        static RepositoryFactor()
        {
            lock (_mapEntity)
            {
                var userRepository = new UserRepository();
                _mapEntity[typeof(User)] = userRepository;
                _mapRepo[typeof(IUserRepository)] = userRepository;

                var contentRepository = new ContentRepository();
                _mapEntity[typeof(Content)] = contentRepository;
                _mapRepo[typeof(IContentRepository)] = contentRepository;
            }
        }

        public static TRepo Resolve<T, TRepo>() where T : class, IEntity where TRepo : IRepository<T>
        {
            object t;
            if (!_mapRepo.TryGetValue(typeof (T), out t))
            {
                _mapEntity.TryGetValue(typeof (T), out t);
            };
            return (TRepo) t;
        }

        //public static TRepo Resolve<TRepo>(Type type) where TRepo : IRepository<IEntity>
        //{
        //    object t;
        //    _map.TryGetValue(type, out t);
        //    return (TRepo)t;
        //} 
       

        public static void Boot()
        {
            foreach (var m in _mapRepo)
            {
                var r = m.Value as IRepsiotrySubcribeChange;
                r.SubscribeAndMakeChange();
            }
        }
    }
}