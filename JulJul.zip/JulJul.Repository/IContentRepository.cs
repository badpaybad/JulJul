﻿using JulJul.Core;
using JulJul.Core.Domain;

namespace JulJul.Repository
{
    public interface IContentRepository : IRepository<Content>
    {
    }
}