﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JulJul.DatabaseCommand
{
    public class Class1
    {
    }
}
